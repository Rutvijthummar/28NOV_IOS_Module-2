//
//  AboutVC.swift
//  Locksmit
//
//  Created by MAC on 06/07/23.
//

import Foundation
import UIKit
import WebKit

// MARK: - Class Of UiViewController -

class AboutVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var webAbout: WKWebView!
    
    var receivedUrl: URL!
    
   // var urlAbout = ""
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // let url=URL(string: receivedUrl)
        let request = URLRequest(url: receivedUrl)
        webAbout.load(request)
        
     /*   let url=URL(string: urlAbout)
        let urlReq=URLRequest(url: url!)
        webAbout.load(urlReq) */
        
    }
    
// MARK: - Button Action Method -
    
    @IBAction func btnBack(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
        
    }
    
}
