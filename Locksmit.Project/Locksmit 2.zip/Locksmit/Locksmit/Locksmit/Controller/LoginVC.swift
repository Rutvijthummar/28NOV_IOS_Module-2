//
//  LoginVC.swift
//  Locksmit
//
//  Created by MAC on 30/06/23.
//

import Foundation
import UIKit
import FirebaseAuth

// MARK: - Class Of UiViewController -

class LoginVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var vwEmail: UIView!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var vwPassword: UIView!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var btnPassword: UIButton!
    
// MARK: - Button Action Method -
    
    @IBAction func btnLoginTapped(_ sender: Any) {
        
        if self.txtEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtPassword.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Password", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        else {
            
            Auth.auth().signIn(withEmail: self.txtEmail.text!, password: self.txtPassword.text!) { (user, error) in
                
                
                
                if error == nil {
                    
                    //Print into the console if successfully logged in
                   // UserDefaults.standard.setValue(true, forKey: "cuser")
                    
                    let alert = UIAlertController(title: "Login", message: "Login Succesfully", preferredStyle: .alert)
                    let actionOK = UIAlertAction(title: "OK", style: .default) { [self] UIAlertAction in
                        
                     //   UserDefaults.standard.setValue(true, forKey: "cuser")
                        
                        let mainTab = self.storyboard?.instantiateViewController(identifier: "TabBarController") as! TabBarController
                        mainTab.modalPresentationStyle = .fullScreen
                        self.present(mainTab, animated: true, completion: nil)
                        
                    }
                    
                    alert.addAction(actionOK)
                    self.present(alert, animated: true, completion: nil)
                    
                    print("You have successfully logged in")
                    
                    //Go to the HomeViewController if the login is sucessful
                 /*   let mainTab = self.storyboard?.instantiateViewController(identifier: "TabBarController")
                    mainTab!.modalPresentationStyle = .fullScreen
                    self.present(mainTab!, animated: true, completion: nil) */
                    
                } else {
                    
                    //Tells the user that there is an error and then gets firebase to tell them the error
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
        
    }
    
    // MARK: - Custom Function Of applystyle -
    
    func ApplyStyle() {
        
        self.vwEmail.layer.borderColor = UIColor.darkGray.cgColor
        self.vwEmail.layer.borderWidth = 1.0
        
        self.vwPassword.layer.borderColor = UIColor.darkGray.cgColor
        self.vwPassword.layer.borderWidth = 1.0
        
        DispatchQueue.main.async {
            
            self.vwEmail.layer.cornerRadius = self.vwEmail.frame.size.height / 2
            
            self.vwPassword.layer.cornerRadius = self.vwPassword.frame.size.height / 2
            
            self.btnLogin.layer.cornerRadius = self.btnLogin.frame.size.height / 2
            
            self.btnSignUp.layer.cornerRadius = self.btnSignUp.frame.size.height / 2
            
        }
        
    }
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ApplyStyle()
        
        
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        
    }
    
// MARK: - Button Action Method -
    
    @IBAction func btnHideShowPasswordTapped(_ sender: Any) {
        
        (sender as! UIButton).isSelected = !(sender as! UIButton).isSelected
        if(sender as! UIButton).isSelected {
            self.txtPassword.isSecureTextEntry = false
            btnPassword.setImage(UIImage(named: "OpenEyes"), for: .normal)
        }
        else {
            self.txtPassword.isSecureTextEntry = true
            btnPassword.setImage(UIImage(named: "HiddenEyes"), for: .normal)
        }
        
    }
    @IBAction func btnResetPasswordTapped(_ sender: Any) {
        
        if self.txtEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let alertController = UIAlertController(title: "Oops!", message: "Please enter an email.", preferredStyle: .alert)
                
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(defaultAction)
                
                present(alertController, animated: true, completion: nil)
            
            } else {
                Auth.auth().sendPasswordReset(withEmail: self.txtEmail.text!, completion: { (error) in
                    
                    var title = ""
                    var message = ""
                    
                    if error != nil {
                        title = "Error!"
                        message = (error?.localizedDescription)!
                    } else {
                        title = "Success!"
                        message = "Password reset email sent."
                        self.txtEmail.text = ""
                    }
                    
                    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                })
            }
        
    }
    @IBAction func btnSignUpTapped(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func btnBackTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}
