//
//  BookingVC.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit
import FirebaseAuth

// MARK: - Class Of UiViewController -

class BookingVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var vwFullName: UIView!
    @IBOutlet weak var txtFullName: UITextField!
    @IBOutlet weak var vwMobileNumber: UIView!
    @IBOutlet weak var vwSelectService: UIView!
    @IBOutlet weak var txtMobileNumber: UITextField!
    @IBOutlet weak var vwSelectDate: UIView!
    @IBOutlet weak var txtSelectService: UITextField!
    @IBOutlet weak var txtSelectDate: UITextField!
    @IBOutlet weak var vwTime: UIView!
    @IBOutlet weak var txtTime: UITextField!
    @IBOutlet weak var tvAddress: UITextView!
    @IBOutlet weak var btnBook: UIButton!
   
    let pickerService = UIPickerView()
    let arrService = ["Salon", "Cleaning", "Haircut", "Appliance Reapair", "Massage Therapy", "Electroinics", "Plumbers", "Painters", "Carpenters", "AC Services & Repair", "Pest Controls", "Yoga & Fitness"]
    
    let pickerDate = UIDatePicker()
    
    // MARK: - Custom Function Of Datepicker -
    
    @objc func setDatePicked(_ picker: UIDatePicker) {
        let dt = picker.date
        print(dt)
        let formatDate = DateFormatter()
        formatDate.dateFormat = "dd MMM yyyy"
        self.txtSelectDate.text = formatDate.string(from: dt)
    }
    
    func dateSelection() {
        
        let currentDate = Date()
        let cal = Calendar(identifier: .gregorian)
        print(currentDate)
        
        
        self.txtSelectDate.inputView = pickerDate
        if #available(iOS 13.4, *) {
            self.pickerDate.preferredDatePickerStyle = .wheels
        }else {
            
        }
        self.pickerDate.datePickerMode = .date
        self.pickerDate.minimumDate = cal.date(byAdding: .year, value: 01, to: currentDate)
        self.pickerDate.maximumDate = currentDate
        
        self.pickerDate.addTarget(self, action: #selector(self.setDatePicked(_:)), for: .valueChanged)
        
    }
    
// MARK: - Button Action Method -
    
    @IBAction func btnBookTapped(_ sender: Any) {
        
        if self.txtFullName.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Book Service", message: "Please Enter Full Name", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtMobileNumber.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Book Service", message: "Please Enter Mobile Number", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtSelectService.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Book Service", message: "Please Select Service", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtSelectDate.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Book Service", message: "Please Select Date", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtTime.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Book Service", message: "Please Enter Time", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.tvAddress.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Book Service", message: "Please Enter Address", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        else {
            let alert = UIAlertController(title: "Book Service", message: "Your Service Has Beem Succesfully Booked", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "OK", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    // MARK: - Custom Function Of applystyle -
    
    func ApplyStyle() {
        
        self.vwFullName.layer.borderColor = UIColor.darkGray.cgColor
        self.vwFullName.layer.borderWidth = 1.0
        
        self.vwMobileNumber.layer.borderColor = UIColor.darkGray.cgColor
        self.vwMobileNumber.layer.borderWidth = 1.0
        
        self.vwSelectService.layer.borderColor = UIColor.darkGray.cgColor
        self.vwSelectService.layer.borderWidth = 1.0
        
        self.vwSelectDate.layer.borderColor = UIColor.darkGray.cgColor
        self.vwSelectDate.layer.borderWidth = 1.0
        
        self.vwTime.layer.borderColor = UIColor.darkGray.cgColor
        self.vwTime.layer.borderWidth = 1.0
        
        self.tvAddress.layer.borderColor = UIColor.darkGray.cgColor
        self.tvAddress.layer.borderWidth = 1.0
        
        
        DispatchQueue.main.async {
            
            self.vwFullName.layer.cornerRadius = self.vwFullName.frame.size.height / 2
            
            self.vwMobileNumber.layer.cornerRadius = self.vwMobileNumber.frame.size.height / 2
            
            self.vwSelectService.layer.cornerRadius = self.vwSelectService.frame.size.height / 2
            
            self.vwSelectDate.layer.cornerRadius = self.vwSelectDate.frame.size.height / 2
            
            self.vwTime.layer.cornerRadius = self.vwTime.frame.size.height / 2
            
            self.tvAddress.layer.cornerRadius = self.tvAddress.frame.size.height / 10
            
            self.btnBook.layer.cornerRadius = self.btnBook.frame.size.height / 2
            
            
            
           
        }
        
    }
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ApplyStyle()
        
        self.pickerService.delegate = self
        self.pickerService.dataSource = self
        
        self.txtSelectService.inputView = pickerService
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        
        dateSelection()
        
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}

// MARK: - UIPickerViewDelegate & UIPickerViewDataSource method -

extension BookingVC: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrService.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        txtSelectService.text = arrService[row]
        return arrService[row]
    }
    
    
}
