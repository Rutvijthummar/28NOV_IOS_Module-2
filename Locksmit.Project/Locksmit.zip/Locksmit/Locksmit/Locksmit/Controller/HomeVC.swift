//
//  HomeVC.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit

// MARK: - Class Of UiViewController -

class HomeVC: UIViewController, UITextFieldDelegate {
    
// MARK: - Button Action Method -
    
    @IBAction func btnLoginTapped(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func btnRegistrationTapped(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
 
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      /*  if UserDefaults.standard.bool(forKey: "cuser")==true
        {
            let mainTab = self.storyboard?.instantiateViewController(identifier: "TabBarController") as! TabBarController
            mainTab.modalPresentationStyle = .fullScreen
            self.present(mainTab, animated: true, completion: nil)
        } */
        
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}



