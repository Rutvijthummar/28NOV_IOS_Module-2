//
//  TabBarController.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit

// MARK: - Class Of UiViewController -

class TabBarController: UITabBarController {
    
}
