//
//  CleaningViewCell.swift
//  Locksmit
//
//  Created by MAC on 27/06/23.
//

import UIKit

// MARK: - Class Of UiViewController -

class CleaningViewCell: UITableViewCell {
    
    
    @IBOutlet weak var imgClean: UIImageView!
    @IBOutlet weak var lblClean: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
